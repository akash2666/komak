package com.example.Admin;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;

import org.springframework.stereotype.Service;

import com.example.entity.Admin;
import com.example.repo.AdminRepository;




@Service
public class DBinit implements CommandLineRunner {
	
	@Autowired
	AdminRepository adrepository;

	Logger logger = LoggerFactory.getLogger(DBinit.class);

	@Override
	public void run(String... args) throws Exception {

		adrepository.save(new Admin(10, "Suresh kumar",9876543210L));
		adrepository.save(new Admin(20, "Hari Madhwa",9834657255L));
		adrepository.save(new Admin(30, "Kiran Singh",8876544516L));
		adrepository.save(new Admin(40, "Sham Kulkarni",7676543245L));
		adrepository.save(new Admin(50, "Paresh Jain",8176532291L));
		
		logger.info("Initial User objects added to the table");

	}

}