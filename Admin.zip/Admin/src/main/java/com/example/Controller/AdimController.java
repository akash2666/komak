package com.example.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.Admin;
import com.example.service.AdminService;

@RestController
@RequestMapping("/admin")
public class AdimController {
	
	@Autowired
	AdminService adminService;
	
	
	@GetMapping("/getAll")
	public List<Admin> getAdmins(){
		return adminService.getAllAdmin();
	}

}
