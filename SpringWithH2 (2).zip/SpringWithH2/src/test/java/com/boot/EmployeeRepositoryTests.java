package com.boot;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertNotNull;

import java.util.List;
import java.util.Optional;

import org.assertj.core.api.Assertions;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.bind.annotation.RequestBody;

import com.boot.entities.Employee;
import com.boot.repo.EmployeeRepository;
import com.boot.service.Services;
@DataJpaTest
//@AutoConfigureTestDatabase(replace=Replace.NONE)
//@Rollback(false)
@SpringBootTest
public class EmployeeRepositoryTests {

		@Autowired
		private EmployeeRepository employeeRepository;
		
		@Autowired
		Services service;	
		
		@Test
		@Ignore("Throws Null Point Exception")
		public void createEmployeeTest() {
			
			Employee employee1=new Employee(22,"pk","pk@gmail.com",3400,null);
			System.out.println(employee1);
			//Employee emp=employeeRepository.save(employee1);
			//Employee ep=service.createEmployee(employee1);
			Assertions.assertThat(employee1.getEmpid()).isGreaterThan(1);
			//Assertions.assertThat(ep.getEmpid()).isGreaterThan(1);
			assertNotNull(employee1);
		}
		
		@Test
		public void getEmployeeByManagerIdTest() throws NullPointerException {
			List<Object[]> employee2=employeeRepository.findBymgid(1);
			System.out.println(employee2);
			Assertions.assertThat(employee2.size()).isEqualTo(0);
			//Assert.assertEquals(0, ((Employee) employee2).getEmpid());

		}
		
		@Test
		public void getAllEmployeeTest() {
			
			List<Employee> employee3=employeeRepository.findAll();
			Assertions.assertThat(employee3.size()).isEqualTo(0);
			System.out.println("employee3");
		}
		
}
