package com.boot;

import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.Ignore;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;

import com.boot.entities.Employee;
import com.boot.entities.RegularEmployee;
import com.boot.repo.EmployeeRepository;
import com.boot.repo.RegularEmpRepository;
import com.boot.service.Services;

@SpringBootTest
//@DataJpaTest
class SpringWithH2ApplicationTests {

	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Autowired
	private RegularEmpRepository regularEmpRepository;
	
	@Autowired
	Services service;	
	
	@Test
	//@Ignore("Throws Null Point Exception")
	public void testcreateEmployee() {
		
		Employee employee1=new Employee(2,"pk","pk@gmail.com",3400,null);
		System.out.println(employee1);
		Employee emp=employeeRepository.save(employee1);
		Assertions.assertThat(emp.getEmpid()).isGreaterThan(1);
		assertNotNull(emp);
	}
	
	@Test
	public void testgetEmployeeByManagerId() {
		List<Object[]> employee2=employeeRepository.findBymgid(1);
		System.out.println(employee2);
		Assertions.assertThat(employee2.size()).isEqualTo(0);

	}
	
	
	
	
	///FOR REGULAR EMPLOYEE TEST CASES
	@Test
	public void testcreateRegularEmployee() {
		
		RegularEmployee regemployee2=new RegularEmployee(22,"pk","pk@gmail.com",3400,null);
		System.out.println(regemployee2);
		RegularEmployee emp1=regularEmpRepository.save(regemployee2);
		Assertions.assertThat(emp1.getRegempName().compareTo("k"));
		assertNotNull(emp1);
	}
	@Test
	public void testgetRegEmployeeByManagerId() {
		List<Object[]> employee3=regularEmpRepository.getRegularEmployeeByManagerId(1);
		System.out.println(employee3);
		Assertions.assertThat(employee3.size()).isEqualTo(0);
		
	}
	
	
}