insert into manager values(1,'akash@gmail.com','akash');
insert into manager values(2,'mahesh@gmail.com','mahesh');
insert into manager values(3,'komal@gmail.com','komal');
insert into manager values(4,'saurabh@gmail.com','saurabh');
insert into manager values(5,'sushil@gmail.com','sushil');
SELECT * FROM MANAGER ;
commit;



insert into REGULAR_EMPLOYEE values(1,2300,'Shrutika@gmail.com','Shrutika',1);
insert into REGULAR_EMPLOYEE values(2,3300,'Raju@gmail.com','Raju',3);
insert into REGULAR_EMPLOYEE values(3,4300,'Gaurav@gmail.com','Gaurav',2);
insert into REGULAR_EMPLOYEE values(4,5300,'Abhi@gmail.com','Abhi',5);
insert into REGULAR_EMPLOYEE values(5,6300,'Shubham@gmail.com','shubham',1);
SELECT * FROM REGULAR_EMPLOYEE;
commit;


insert into EMPLOYEE values(1,'Durodhan@gmail.com','Durodhan',6300,1);
insert into EMPLOYEE values(2,'Ram@gmail.com','Ram',3300,3);
insert into EMPLOYEE values(3,'Lakshman@gmail.com','Lakshman',8300,2);
insert into EMPLOYEE values(4,'Raone@gmail.com','Raone',4300,4);
insert into EMPLOYEE values(5,'Ram@gmail.com','Ram',7300,1);
insert into EMPLOYEE values(6,'Krushna@gmail.com','Krushna',2300,1);
SELECT * FROM REGULAR_EMPLOYEE;
commit;