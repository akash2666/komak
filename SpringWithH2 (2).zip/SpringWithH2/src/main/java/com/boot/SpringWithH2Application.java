package com.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
//@EntityScan({"com.boot.entities"})
//@ComponentScan({"com.boot.controller.EmployeeController"})
@SpringBootApplication
public class SpringWithH2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringWithH2Application.class, args);
		
		System.out.println("Spring with H2 Database Configured Sucessfully........!!!!!!!!");
	}

}
