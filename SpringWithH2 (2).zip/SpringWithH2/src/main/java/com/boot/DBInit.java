package com.boot;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;

import com.boot.entities.Employee;
import com.boot.entities.Manager;
import com.boot.entities.RegularEmployee;
import com.boot.repo.EmployeeRepository;
import com.boot.repo.ManagerRepository;
import com.boot.repo.RegularEmpRepository;

public class DBInit implements CommandLineRunner {

	
	@Autowired
	EmployeeRepository empRepo;
	@Autowired
	RegularEmpRepository regEmpRepo;
	
	@Autowired
	ManagerRepository manRepo;
	
	
	@Override
	public void run(String... args) throws Exception {
		
		empRepo.save(new Employee(100,"abb","aak@kk",20000.0f,null));
		empRepo.save(new Employee(200,"abb","aak@kk",20000.0f,null));
		empRepo.save(new Employee(300,"abb","aak@kk",20000.0f,null));
		empRepo.save(new Employee(400,"abb","aak@kk",20000.0f,null));
		
		
		regEmpRepo.save(new RegularEmployee(10,"kk","kk@k",2300.0f,null));
		regEmpRepo.save(new RegularEmployee(20,"kk","kk@k",2300.0f,null));
		regEmpRepo.save(new RegularEmployee(30,"kk","kk@k",2300.0f,null));

		
		manRepo.save(new Manager(11,"Man","man@m"));
		manRepo.save(new Manager(22,"Man","man@m"));
		manRepo.save(new Manager(33,"Man","man@m"));
		
		
	}

}
