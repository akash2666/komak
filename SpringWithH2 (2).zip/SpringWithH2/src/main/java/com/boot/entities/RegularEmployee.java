package com.boot.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;

import javax.persistence.OneToOne;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;



@Entity

public class RegularEmployee {
	@Id
	private int regempId;
	
	@Column(length=15)
	@NotNull
	@NotBlank(message = "name is required")
	private String regempName;
	
	@Column(length=25)
	@NotNull
	@Email
	@NotBlank(message = "Email is required")
	private String regempEmail;
	
	@Column(length=15)
	private float regSalary;
	
	@OneToOne
	@JoinColumn(name = "mgid")
	private Manager manager;
	
	

	public RegularEmployee() {
		super();
	}



	public RegularEmployee(int regempId, String regempName, String regempEmail, float regSalary, Manager manager) {
		super();
		this.regempId = regempId;
		this.regempName = regempName;
		this.regempEmail = regempEmail;
		this.regSalary = regSalary;
		this.manager = manager;
	}



	public int getRegempId() {
		return regempId;
	}



	public void setRegempId(int regempId) {
		this.regempId = regempId;
	}



	public String getRegempName() {
		return regempName;
	}



	public void setRegempName(String regempName) {
		this.regempName = regempName;
	}



	public String getRegempEmail() {
		return regempEmail;
	}



	public void setRegempEmail(String regempEmail) {
		this.regempEmail = regempEmail;
	}



	public float getRegSalary() {
		return regSalary;
	}



	public void setRegSalary(float regSalary) {
		this.regSalary = regSalary;
	}



	public Manager getManager() {
		return manager;
	}



	public void setManager(Manager manager) {
		this.manager = manager;
	}



	@Override
	public String toString() {
		return "RegularEmployee [regempId=" + regempId + ", regempName=" + regempName + ", regempEmail=" + regempEmail
				+ ", regSalary=" + regSalary + ", manager=" + manager + "]";
	}

	
	
}
