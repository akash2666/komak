package com.boot.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.Builder;
import lombok.Data;




@Entity
@Data
public class Employee {
	
	@Id
	
	private int empid;
	
	@Column(length=15)
	@NotNull
	@NotBlank(message = "name is required")
	private String empfname;
	
	@Column(length=25)
	@NotNull
	@Email
	@NotBlank(message = "Email is required")
	private String empemail;
	
	@Column(length=15)
	private float salary;
	
	@OneToOne
	@JoinColumn(name = "mgid")
	private Manager manager;
	
	
	
	public Employee(Manager manager) {
		super();
		this.manager = manager;
	}



	public Employee() {
		super();
	}



	public Employee(int empid, String empfname, String empemail, float salary,Manager manager ) {
		super();
		this.empid = empid;
		this.empfname = empfname;
		this.empemail = empemail;
		this.salary = salary;
		this.manager = manager;
	}



	public int getEmpid() {
		return empid;
	}



	public void setEmpid(int empid) {
		this.empid = empid;
	}



	public String getEmpfname() {
		return empfname;
	}



	public void setEmpfname(String empfname) {
		this.empfname = empfname;
	}



	public String getEmpemail() {
		return empemail;
	}



	public void setEmpemail(String empemail) {
		this.empemail = empemail;
	}



	public float getSalary() {
		return salary;
	}



	public void setSalary(float salary) {
		this.salary = salary;
	}



	public Manager getManager() {
		return manager;
	}



	public void setManager(Manager manager) {
		this.manager = manager;
	}



	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", empfname=" + empfname + ", empemail=" + empemail + ", salary=" + salary
				+ ", manager=" + manager + "]";
	}

	
	
}
