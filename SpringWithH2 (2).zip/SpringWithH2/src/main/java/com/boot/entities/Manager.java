package com.boot.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;



@Entity

public class Manager {
	@Id
	private int mgid;
	
	@Column(length=15)
	@NotNull
	@NotBlank(message = "name is required")
	private String mgname;
	
	@Column(length=25)
	@NotNull
	@Email
	@NotBlank(message = "Email is required")
	private String mgemail;
	


	public Manager() {
		super();
	}

	


	//public Manager(int mgid) {
	//	super();
	//	this.mgid = mgid;
	//}




	public Manager(int mgid, String mgname, String mgemail) {
		super();
		this.mgid = mgid;
		this.mgname = mgname;
		this.mgemail = mgemail;
	}



	public int getMgid() {
		return mgid;
	}



	public void setMgid(int mgid) {
		this.mgid = mgid;
	}



	public String getMgname() {
		return mgname;
	}



	public void setMgname(String mgname) {
		this.mgname = mgname;
	}



	public String getMgemail() {
		return mgemail;
	}



	public void setMgemail(String mgemail) {
		this.mgemail = mgemail;
	}



	@Override
	public String toString() {
		return "Manager [mgid=" + mgid + ", mgname=" + mgname + ", mgemail=" + mgemail + "]";
	}
	
	
	
	

}
