package com.boot.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.boot.entities.RegularEmployee;

public interface RegularEmpRepository extends JpaRepository<RegularEmployee,Integer>  {
	
	
	
	@Query( value ="select regempName,regempEmail,regSalary from RegularEmployee where mgid=:mgid")
	List<Object[]> getRegularEmployeeByManagerId(@Param("mgid") int mgid);

	//@Query("select e.regempid,e.regempfname,e.regsalary,e.regempemail from RegularEmployee e where e.mgid=:mgid")
	//public Optional<RegularEmployee> findRegularEmployeeByManagerId(@Param("mgid") int mgid);	
	
}

	

	
	
