import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/interfaces/product';
import { ProductService } from 'src/app/service/product.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  pp: Product[]=[]
  
  constructor(private productService: ProductService) { }

  ngOnInit(): void {
    this.productService.getall().subscribe(
      pp =>{
          this.pp=pp
          console.warn(pp);
      }
    )
  }

}
