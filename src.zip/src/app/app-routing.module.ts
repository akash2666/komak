import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminComponent } from './admin/admin.component';
import { ProductCreateComponent } from './admin/product-create/product-create.component';
import { ProductEditComponent } from './admin/product-edit/product-edit.component';
import { ProductHomeComponent } from './admin/product-home/product-home.component';
import { ProductsComponent } from './admin/products/products.component';
import { MainComponent } from './main/main.component';
import { HomeComponent } from './user/home/home.component';
import { ProductComponent } from './user/product/product.component';
import { UserComponent } from './user/user.component';

const routes: Routes = [
  {path:'', component: MainComponent},
  
  {path:'admin', component: AdminComponent,
  children: [
    {path:'product',component: ProductsComponent},
    {path:'home',component: ProductHomeComponent},
    {path:'product/create',component: ProductCreateComponent},
    {path:'product/:id/edit',component: ProductEditComponent}
            ]
 },
      {path:'user', component: UserComponent,
        children: [
             {path:'product',component: ProductComponent},
             {path:'home',component: HomeComponent}
        ]
      }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
