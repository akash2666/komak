package com.mph.SpringBootWithH2Database;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@EntityScan({"com.mph.model"})

@ComponentScan({"com.mph.controller.EmployeeController"})
public class SpringBootWithH2DatabaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootWithH2DatabaseApplication.class, args);
		System.out.println("Spring Boot with h2 Database Configured");

	}

}
