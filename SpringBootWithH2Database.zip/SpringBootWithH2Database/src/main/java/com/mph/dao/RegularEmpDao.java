package com.mph.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.mph.model.Employee;
import com.mph.model.RegularEmployee;

public interface RegularEmpDao extends JpaRepository<RegularEmployee,Long>  {
	@Query("select e.regempid,e.regempfname,e.regsalary,e.regempemail from RegularEmployee e where e.mgid=:mgid")
	Optional<RegularEmployee> findRegularEmployeeByManagerId(@Param("mgid") Long mgid);
	
}
