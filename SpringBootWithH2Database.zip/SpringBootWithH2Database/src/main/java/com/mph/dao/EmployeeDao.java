package com.mph.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.mph.model.Employee;

public interface EmployeeDao extends JpaRepository<Employee,Long> {
	@Query("select e.empid,e.empfname,e.salary,e.empemail from Employee e where e.mgid=:mgid")
	Optional<Employee> findEmployeeByManagerId(@Param("mgid") Long mgid);
	
}
