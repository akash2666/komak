package com.mph.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mph.dao.EmployeeDao;
import com.mph.dao.RegularEmpDao;
import com.mph.model.Employee;
import com.mph.model.Manager;
import com.mph.model.RegularEmployee;

@RestController
@RequestMapping("/Employee")
public class EmployeeController {
	
	@Autowired
	private EmployeeDao employeeDao;
	@Autowired
	private RegularEmpDao regularEmpDao;
	

	////For employee  creation and employee with designation with manager
	@PostMapping//("/createEmployee")
	public Employee createEmployee(@RequestBody Employee employee)
	{
		return employeeDao.save(employee);
	}
	
	@GetMapping//("/getAllEmployee")
	public List<Employee> getAllEmployee(){
		return employeeDao.findAll();
	}
	
	@GetMapping("/getEmployeeByManagerId/{mgid}")
	public Optional<Employee> getEmployeeByManagerId(@PathVariable Long mgid) {
		return employeeDao.findEmployeeByManagerId(mgid);
		
	}
	
	///for Creating RegularEmployee and Regular employee with designation with manager
	@PostMapping("/createRegularEmployee")
	public RegularEmployee createRegularEmployee(@RequestBody RegularEmployee regularEmployee)
	{
		return regularEmpDao.save(regularEmployee);
	}
	
	@GetMapping//("/getAllRegularEmployee")
	public List<RegularEmployee> getAllReagularEmployee(){
		return regularEmpDao.findAll();
	}
	
	@GetMapping("/getEmployeeByManagerId/{mgid}")
	public Optional<RegularEmployee> getRegularEmployeeByManagerId(@PathVariable Long mgid) {
		return regularEmpDao.findRegularEmployeeByManagerId(mgid);
		
	}
	
}









