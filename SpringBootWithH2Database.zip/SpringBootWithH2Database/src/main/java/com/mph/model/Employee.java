package com.mph.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;


@Entity
@Data
public class Employee {
	

	public Employee(Long empid, String empfname, String empemail, float salary, Manager manager) {
		super();
		this.empid = empid;
		this.empfname = empfname;
		this.empemail = empemail;
		this.salary = salary;
		this.manager = manager;
	}

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long empid;
	
	@Column
	private String empfname;
	
	@Column
	private String empemail;
	
	@Column
	private float salary;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "mgid")
	private Manager manager;

	
}
