package com.mph.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import lombok.Data;

@Entity
@Data
public class RegularEmployee {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long regempId;
	
	@Column
	private String regempName;
	
	@Column
	private String regempEmail;
	
	@Column
	private float regSalary;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "mgid")
	private Manager manager;

	public RegularEmployee(Long regempId, String regempName, String regempEmail, float regSalary, Manager manager) {
		super();
		this.regempId = regempId;
		this.regempName = regempName;
		this.regempEmail = regempEmail;
		this.regSalary = regSalary;
		this.manager = manager;
	}

	
}
