package com.mph.controller;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.mph.dao.EmployeeDao;
import com.mph.dao.RegularEmpDao;
import com.mph.model.Employee;
import com.mph.model.RegularEmployee;
@DataJpaTest
class EmployeeControllerTest {

	@Autowired
	private EmployeeDao employeeDao;
	@Autowired
	private RegularEmpDao regularEmpDao;


	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		System.out.println("Setting up....");
	}

	

	@Test
	void testCreateEmployee() {
		Employee employee=new Employee((long) 1, "aka", "akash@gmail.com", 2400,null);
		employeeDao.save(employee);
	}

	@Test
	void testGetEmployeeByManagerId() {
		
	}

	@Test
	void testCreateRegularEmployee() {
		RegularEmployee regularEmployee=new RegularEmployee((long) 1, "akash","akash@gmail.com", 2300, null);
		regularEmpDao.save(regularEmployee);
	}

	@Test
	void testGetRegularEmployeeByManagerId() {
		
	}
	@AfterAll
	static void tearDownAfterClass() throws Exception {
		System.out.println("tearing down....");
	}

}
