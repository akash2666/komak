package com.boot.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.boot.entities.Manager;

public interface ManagerRepository extends JpaRepository<Manager,Long>{

	List<Manager> findBymgid(int mgid);

}
