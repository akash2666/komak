package com.boot.repo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.boot.entities.Employee;
import com.boot.entities.Manager;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee,Integer> {
	public static final Connection con = null;
	//@Query("select e.empid,e.empfname,e.salary,e.empemail from Employee e where e.mgid=:mgid")
	//@Query("select * from employee where empid=:mgid")
	//public default ResultSet findEmployeeByManagerId( int mgid) 

	//@Query("select e.empid,e.empfname,e.salary,e.empemail from Employee e where manager.mgid=:mgid")
	// List<Employee> findBymgid(@Param("mgid") int mgid);

		
		


	

	
	

	
	
	
}
