package com.boot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.boot.entities.Employee;
import com.boot.entities.Manager;
import com.boot.repo.EmployeeRepository;
import com.boot.repo.ManagerRepository;
import com.boot.repo.RegularEmpRepository;
import com.boot.entities.RegularEmployee;


@Service
public class Services {
	
	@Autowired
	EmployeeRepository empRepo;
	@Autowired
	RegularEmpRepository regEmpRepo;
	@Autowired
	ManagerRepository manRepo;
	
	public  Employee  createEmployee(Employee emp )
	{
		return empRepo.save(emp);
	}
	
	public  List<Employee> getAllEmployee(){
		return empRepo.findAll();
	}
	/*
	public Optional<Employee> getEmployeeByManagerId( int mgid) {
		 return empRepo.findEmployeeByManagerId(mgid);
		
	}
	*/
	
	public RegularEmployee createRegularEmployee(RegularEmployee regularEmployee)
	{
		return regEmpRepo.save(regularEmployee);
	}
	
	public  List<RegularEmployee> getAllReagularEmployee(){
		 return regEmpRepo.findAll();
	}

	
	/*public Optional<RegularEmployee> getRegularEmployeeByManagerId( int mgid) {
		 return regEmpRepo.findRegularEmployeeByManagerId(mgid);
		
	}
	*/

}
