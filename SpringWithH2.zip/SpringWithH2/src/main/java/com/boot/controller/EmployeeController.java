package com.boot.controller;

import java.sql.ResultSet;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.boot.entities.Employee;
import com.boot.entities.Manager;
import com.boot.entities.RegularEmployee;
import com.boot.repo.EmployeeRepository;
import com.boot.repo.ManagerRepository;
import com.boot.repo.RegularEmpRepository;
import com.boot.service.Services;



@RestController
@RequestMapping("employee")
public class EmployeeController {
	
	@Autowired
	Services service;
	@Autowired
	EmployeeRepository empRepo;
	@Autowired
	ManagerRepository mgRepo;
	@Autowired
	RegularEmpRepository regempRepo;
	////For employee  creation and employee with designation with manager
	@PostMapping()
	public Employee createEmployee(@RequestBody Employee employee)
	{
		return service.createEmployee(employee);
	}
	
	@GetMapping("getAll")
	public List<Employee> getAllEmployee(){
		return service.getAllEmployee();
	}
	
	@GetMapping("getEmployeeByManagerId/{managerid}")
	List<Object[]> getEmployeeByManagerId(@PathVariable("managerid") int mgid) {
		//System.out.println(empRepo.findBymgid(mgid));/
		return empRepo.findBymgid(mgid);
		
	}
	
	///for Creating RegularEmployee and Regular employee with designation with manager
	@PostMapping("createRegularEmployee")
	public RegularEmployee createRegularEmployee(@RequestBody RegularEmployee regularEmployee)
	{
		return service.createRegularEmployee(regularEmployee);
	}
	
	@GetMapping("getAllRegular")
	public List<RegularEmployee> getAllReagularEmployee(){
		return service.getAllReagularEmployee();
	}
	
	@GetMapping("getRegEmployeeByManagerId/{managerid}")
	List<Object[]> getRegularEmployeeByManagerId(@PathVariable("managerid") int mgid) {
		return regempRepo.getRegularEmployeeByManagerId(mgid);
		
	}
	
}









