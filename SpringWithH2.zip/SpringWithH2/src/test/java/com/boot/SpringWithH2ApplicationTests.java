package com.boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.boot.entities.Employee;
import com.boot.repo.EmployeeRepository;



class SpringWithH2ApplicationTests {
	private EmployeeRepository employeeDao;
	@Test
	void testCreateEmployee() {
		//Employee employee=new Employee(4, "akash@gmail.com","aka", 2400, null);
		//employeeDao.save(employee);
		//System.out.println(employeeDao.existsById(0));
	}

}
