package com.boot;

import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.boot.entities.Employee;
import com.boot.repo.EmployeeRepository;
//@Ignore("Throws Null Point Exception")
@DataJpaTest
public class EmployeeRepositoryTests {

		@Autowired
		private EmployeeRepository employeeRepository;

		@Test
		public void saveEmployeeTest() {
			Employee employee=new Employee(22,"akash","akash@gmail.com",3400,null);
			employeeRepository.save(employee);
			Assertions.assertThat(employee.getEmpid()).isGreaterThan(0);
		}
		
		@Test
		public void getEmployeeTest() {
			Employee employee=employeeRepository.findById(1).get();
			Assertions.assertThat(employee.getEmpid()).isEqualTo(0);
		}
		
		@Test
		public void getListEmployeeTest() {
			
			List<Employee> employee=employeeRepository.findAll();
			Assertions.assertThat(employee.size()).isEqualTo(0);
			System.out.println("employee");
		}
		
		@Test
		public void getLListEmployeeTest() {
			Employee employee=new Employee();
			Assert.assertEquals(0, employee.getEmpid());
			System.out.println(employee.getEmpid());

		}
		
}
