package com.boot;

import java.util.List;
import java.util.Optional;

import org.assertj.core.api.Assertions;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.boot.entities.Employee;
import com.boot.repo.EmployeeRepository;
import com.boot.service.Services;
@DataJpaTest
public class EmployeeRepositoryTests {

		@Autowired
		private EmployeeRepository employeeRepository;
		@Autowired
		Services service;
		@Test
		//@Ignore("Throws Null Point Exception")
		public void saveEmployeeTest() {
			
			Employee employee1=new Employee(22,"akash","akash@gmail.com",3400,null);
			System.out.println(employee1);
			//employeeRepository.save(employee1);
			//service.createEmployee(employee1);
			Assertions.assertThat(employee1.getEmpid()).isGreaterThan(0);
		}
		
		@Test
		public void getEmployeeTest() {
			Employee employee2=employeeRepository.findById(1).get();
			System.out.println(employee2);
			Assertions.assertThat(employee2.getEmpid()).isEqualTo(1);
		}
		
		@Test
		public void getListEmployeeTest() {
			
			List<Employee> employee3=employeeRepository.findAll();
			Assertions.assertThat(employee3.size()).isEqualTo(0);
			System.out.println("employee3");
		}
		
		@Test
		public void getLListEmployeeTest() {
			//Employee employee4=new Employee();
			//Assert.assertEquals(0, employee4.getEmpid());
			List<Employee> employeee5= service.getAllEmployee();
			System.out.println(employeee5);
		}
		
}
